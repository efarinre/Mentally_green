# read in necessary packages
library(tidyverse)
library(INLA)
library(spdep)
library(SpatialEpi)
library(ggplot2)
library(plyr)
library(dplyr)
library(readr)
library(sf)
library(rgdal)
library(tmap)
library(RSQLite)
library(tmaptools)
library(leaflet)
library(htmltools)
library(broom)
library(plotly) 
library(geojsonio) 
library(mapview) 
library(crosstalk)
library(viridis)
library(reshape2)
library(shinyjs)
library(janitor)
library(car)
library(corrplot)
library(shades)
library(ggpubr)

# read in the postcode -> OA -> LSOA -> MSOA -> LA lookup table. filter for cornwall and devon
# this will be my rural comparison to london

cornwall <-  read_csv(("N:/Term 3/ucfnefa/PCD_OA_LSOA_MSOA_LAD_NOV20_UK_LU/PCD_OA_LSOA_MSOA_LAD_NOV20_UK_LU.csv"),
                      col_names = TRUE,
                      locale = locale(encoding = "Latin1")) %>%
  dplyr::filter(str_detect(ladnm, "Cornwall"))
head(cornwall)

# keep the code and name columns only
cornwall <- cornwall[c("lsoa11cd", "lsoa11nm")]
# remove the duplicate lsoa rows, given that there is a row for each postcode
cornwall <- cornwall[!duplicated(cornwall[,c("lsoa11cd", "lsoa11nm")]),]


# Reading in the map of emgland with the lsoa boundaries
england_lsoas <- st_read("N:/Term 3/ucfnefa/Lower_Layer_Super_Output_Areas__December_2011__Boundaries_Full_Extent__BFE__EW_V3-shp/Lower_Layer_Super_Output_Areas__December_2011__Boundaries_Full_Extent__BFE__EW_V3.shp")
head(england_lsoas)

cornwall_lsoas <- inner_join(england_lsoas, cornwall, by = c("LSOA11CD" = "lsoa11cd"))
cornwall_lsoas <- cornwall_lsoas[c("LSOA11CD", "LSOA11NM")]
head(cornwall_lsoas)

# plot the outline
plot(cornwall_lsoas)

# plotting just the outline of the shape
cornwall_lsoas %>%
  st_geometry() %>%
  plot()


### time to start reading in the covariates for cornwall. Unlike London, Cornwall does not have a data store
# so some of the covariates wil have to be calculated here
# let's start by erading in the social renting % column which is already calculated
social_renting <- read_csv("N:/Term 3/ucfnefa/cornwall_socialrenting.csv")
names(social_renting) <- c("names", "codes", "socialrenting_pc")
head(social_renting)

# now for the economic activity. you'll need to calculate the unemployment rate (economically active people who are unemployed)
# by divided the two columns and rounding to 1 decimal place to match the London rates
unemployment <- read_csv("N:/Term 3/ucfnefa/cornwall_economicactivity.csv")
names(unemployment) <- c("names", "code", "active", "unemployed")
unemployment$unemployed_pc <- round(unemployment$unemployed/unemployment$active, digits = 1)
unemployment <- unemployment[c("code", "unemployed_pc")]
head(unemployment)

# merge the two together
covariates1 <- inner_join(unemployment, social_renting, by = c("code" = "codes"))
head(covariates1)
# reorder the columns
covariates1 <- covariates1[c("code", "names", "unemployed_pc", "socialrenting_pc")]


# now read in the persons per hectare data
popden <- read_csv("N:/Term 3/ucfnefa/england_popdensity.csv")
names(popden) <- c("names", "code", "pop_density")
popden <- popden[c("code", "pop_density")]

covariates1 <- inner_join(covariates1, popden, by = c("code" = "code"))
head(covariates1)


# now read in the ethnicity grouping data
ethnicity <- read_csv("N:/Term 3/ucfnefa/cornwall_ethnicity.csv")
head(ethnicity)
names(ethnicity) <- c("names", "codes", "white_pc", "mixed_pc", "asian_pc", "black_pc", "other_pc")
ethnicity$bame_pc <- round(ethnicity$mixed_pc + ethnicity$asian_pc + ethnicity$black_pc + 
                             ethnicity$other_pc, digits = 1)
#drop the names column
ethnicity <- ethnicity[c("codes", "white_pc", "mixed_pc", "asian_pc", "black_pc", "other_pc", "bame_pc")]
head(ethnicity)

# merge with covariates1
covariates1 <- inner_join(covariates1, ethnicity, by = c("code" = "codes"))
head(covariates1)




#################### now read in the CDRC Access to Health Assets and Hazards dataset # raw scores
covariates2 <- read_csv("N:/Term 3/ucfnefa/allvariableslsoawdeciles.csv")
head(covariates2)
# filter for the lsoa code,  gp, a&e, pharmacy, green (passive) and green (active) accessbitlity columns
covariates2 <- covariates2[c("lsoa11", "gpp_dist", "ed_dist", "pharm_dist", "green_pas", "green_act")]
head(covariates2)
names(covariates2) <- c("lsoa", "gp_access", "ae_access", "pharm_access", "green_access_prop", "green_access_dist")


#################### read in the composite INDEX values CDRC Access to Health Assets and Hazards dataset 
covariates3 <- read_csv("N:/Term 3/ucfnefa/ahahv2domainsindex.csv")
head(covariates3)
# filter for the lsoa code, health domain deciles and blue/green space domain deciles columns
covariates3 <- covariates3[c("lsoa11", "h_exp", "g_exp", "h_dec", "g_dec")]
head(covariates3)
names(covariates3) <- c("lsoa","health_access_valexp", "greenblue_access_valexp", "health_access_deciles", "greenblue_access_deciles")



# merge the dataframes together
covariates <- inner_join(covariates1, covariates2, by = c("code" = "lsoa"))
head(covariates)
# add the remaing columns via another merge
covariates <- inner_join(covariates, covariates3, by = c("code" = "lsoa"))
head(covariates)

# Checking for na values
apply(covariates, 2, function(x) any(is.na(x)))


cornwall_covariates <- covariates

# clean the names
cornwall_covariates <- cornwall_covariates %>%
  clean_names()
head(cornwall_covariates)



########### Checking the distribution of the covariates
###### I'll also use Tukey's ladder of transformations to see if and how the covariates need to be transformed
## Persons per hectare - population density
ggplot(cornwall_covariates, aes(x = pop_density)) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 10) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)

symbox(~pop_density, 
       cornwall_covariates,
       na.rm=T,
       powers = seq(-2,2,by=.5))


## Total BAME ethnic percentage
ggplot(cornwall_covariates, aes(x = bame_pc )) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 0.05) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)

symbox(~bame_pc, 
       cornwall_covariates,
       na.rm=T,
       powers = seq(-2,2,by=.5))


## Green space (passive) access 
ggplot(cornwall_covariates, aes(x = green_access_prop)) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 0.1) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)    

symbox(~green_access_prop, 
       cornwall_covariates,
       na.rm=T,
       powers = seq(-2,2,by=.5))

## Green space (active) access 
ggplot(cornwall_covariates, aes(x = green_access_dist)) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 0.1) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)

symbox(~green_access_dist, 
       cornwall_covariates,
       na.rm=T,
       powers = seq(-2,2,by=.5))


## Socially rented accomodation %
ggplot(cornwall_covariates, aes(x = socialrenting_pc)) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 1) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)

symbox(~socialrenting_pc, 
       cornwall_covariates,
       na.rm=T,
       powers = seq(-2,2,by=.5))


## Unemployment rate
ggplot(cornwall_covariates, aes(x = unemployed_pc)) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 0.1) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)

symbox(~unemployed_pc, 
       cornwall_covariates,
       na.rm=T,
       powers = seq(-2,2,by=.5))




################################# read in neuro-psychiatric hospitalisation data: observed counts, 
#expected counted and standardised mortality ratio have already been computed 
d2011 <- read_csv("N:/Term 3/emmanuel/data/dataLSOA1y/UK83C_gbd1a0_2E_2011.csv")

# take only relevant columns
d2011 <- d2011[, c("X1", "eObs", "eExp", "smr")]
# rename columns
names(d2011) <- c("lsoa", "Y", "E", "SMR")
head(d2011)

# merge with the ldn_covariates data frame
all_vars <- inner_join(cornwall_covariates, d2011, by = c("code" = "lsoa"))
head(all_vars)

# reorder the columns
all_vars <- all_vars[c("code", "names", "Y", "E", "SMR", "pop_density", 
                       "green_access_prop", "green_access_dist", 
                       "unemployed_pc", "socialrenting_pc","bame_pc")]

# reorder the rows
all_vars <- all_vars[order(all_vars$names),]

# We need to create index vectors for the lsoas that will be used to specify the random effects of the model
all_vars$area_u <- 1:nrow(all_vars)
head(all_vars)

# we need to make a second index vector for the lsoas because there are two different random effects
all_vars$area_v <- all_vars$area_u
head(all_vars)



############ computing means 
mean(all_vars$pop_density) # 15.7
range(all_vars$pop_density)

mean(all_vars$green_access_prop) # 0.13
range(all_vars$green_access_prop)

mean(all_vars$green_access_dist) # 0.84
range(all_vars$green_access_dist)

mean(all_vars$unemployed_pc) # 0.04
range(all_vars$unemployed_pc)

mean(all_vars$socialrenting_pc) # 12.1
range(all_vars$socialrenting_pc)

mean(all_vars$bame_pc) # 1.76
range(all_vars$bame_pc)

######################################
# what shape is the observed data? want to see which model is most suitable
ggplot(all_vars, aes(x = Y )) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 1) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)






### before modelling, I will plot an interactive map of the 2011 SMRs across London
##############################################################

# join Cornwall data with the map of Cornwall 
map <- inner_join(cornwall_lsoas, all_vars, by = c("LSOA11CD" = "code"))
# drop the repeated lso names column
drop <-  c("names")
map <- map[,!(names(map) %in% drop)]



# For the interactive map, because I'm using leaflet, I Need '+proj=longlat +datum=WGS84' 

# Checking projection of my map of Cornwall
print(map) #Returns Projected CRS: OSGB 1936 / British National Grid
# which has the epsg code of 4326

# Reproject
mapREPROJECTED <- map %>%
  st_transform(., 4326)
print(mapREPROJECTED)

# Now we'll improve that map by hghlighting things about the lsoa as the mose hovers over them
pal <- colorNumeric(palette = "YlOrRd", domain = mapREPROJECTED$SMR)

labels <- sprintf("<strong> %s </strong> <br/> Observed: %s <br/> Expected: %s <br/>
                  Population density: %s <br/> SMR: %s",
                  mapREPROJECTED$LSOA11NM, mapREPROJECTED$Y, round(mapREPROJECTED$E, 2),
                  mapREPROJECTED$pop_density, round(mapREPROJECTED$SMR, 2)) %>%
  lapply(htmltools::HTML)

twenty_11 <- leaflet(mapREPROJECTED) %>% addTiles() %>%
  addPolygons(color = "grey", weight = 1, fillColor = ~pal(SMR), fillOpacity = 0.5,
              highlightOptions = highlightOptions(weight = 4), label = labels,
              labelOptions = labelOptions(style = list("font-weight" = "normal",
                                                       padding = "3px 8px"),
                                          textsize = "15px",
                                          direction = "auto")) %>%
  addLegend(pal = pal, values = ~SMR, opacity = 0.5, title = "SMR",
            position = "bottomright")

twenty_11



####### extracting SMR mean, range, and 90/10 quantile ratio
mean(all_vars$SMR)
range(all_vars$SMR)

# most at risk / least at risk
ninety <- quantile(all_vars$SMR, .90)
ten <- quantile(all_vars$SMR, .10)
ninety/ten



############### Computing Correlation Matrix

cMartixVars <- all_vars[c("pop_density", 
                       "green_access_prop", "green_access_dist", 
                       "unemployed_pc", "socialrenting_pc","bame_pc")]

cMatrix <- cor(cMartixVars)
head(round(cMatrix, 2))

corrplot(cMatrix, method = "number")



############################ MODELLING using the Bernardinelli model (Bernadinelli et al., 1995)

# First we need to create a neighbourhood matrix to define the spatial random effect
#by using the poly2nb() and the nb2INLA() functions of the spdep package (Bivand, 2019).
nb <- poly2nb(cornwall_lsoas)
head(nb)
#class(nb)

# create the neighbours matrix
#nb2INLA("cornwall.adj", nb)
g <- inla.read.graph(filename = "cornwall.adj")
#summary(g)
#head(g)





# Now write the formula of the Bernardinelli model:
# Model 0000000000000000000000 zero - just the unstructuctured spatial residual Vi
# I will then compute MORAN'S I to check for spatial autocorrelation in the RR
formula0 <- Y ~ log(pop_density) + log(green_access_prop) + log(green_access_dist) +
  f(area_v, model = "iid")

cornwall_model0 <- inla(formula0,
                   family= "poisson", data = all_vars, E=E,
                   control.compute = (list(dic = TRUE)),
                   control.predictor = list(compute = TRUE)
)
summary(cornwall_model0)
saveRDS(cornwall_model0, "cornwall_model0.rds")


# NOW for Moran's I
# We'll keep with the Queen's neighbourhood structure as it is the default (used here) 
# for the INLA models. We'll also use the Binary spatial weights

# Creating the binary spatial weights matric from the queens neighbourhood structure
lsoa_weights_m <- nb %>%
  nb2mat(., style = "B")
sum(lsoa_weights_m)

# changing the spatial weights matrix into a list as Moran's I requires it this way
lsoa_weights_m <- nb %>%
  nb2listw(., style = "B")

# Extract the residuals
head(cornwall_model0$summary.random$area_v)
residuals_vi <- cornwall_model0$summary.random$area_v[,"mean"]
head(residuals_vi)


# Going to use the Monte-Carlo simulation of Moran's I, rather than the basic analytical approach of 
# The analytical apprach is fast, but the MC simulative approach is a safer approach as it takes an 
# extra argument n, the number of simulations
I_Llsoa_binary <- moran.mc(x = residuals_vi, listw = lsoa_weights_m, nsim = 1000)   
I_Llsoa_binary


















                                             #with LOGGED COVARIATES #
######################################################################################             

# 1st only with the green access and popden covariates
formula1_log <- Y ~ log(pop_density) + log(green_access_prop) + log(green_access_dist) + 
  f(area_u, model = "besag", graph = g) +
  f(area_v, model = "iid")

cornwall_model1_log <- inla(formula1_log,
                            family = "poisson", data = all_vars, E = E,
                            control.compute = (list(dic = TRUE)),
                            control.predictor = list(compute = TRUE)
)
summary(cornwall_model1_log)
saveRDS(cornwall_model1_log, "cornwall_model1_log.rds")


######### 1.5
# this model initially gave an error as 4 logged values became Inf's, suggesting that there were zeros or negative values
# After inspection it turns out there are neither negative values nor zeros in any of the columns,
# however, the social renting column has a few values that are close to zeo (e.g. 0.4) 
# so I will apply  log(UNEMPLOYED pc + 1) and see if it works

# MODEL 1.5 with the green access and popden covariates AND sociodemographic variables. I.e., without
# the health access variables
formula1.5_log <- Y ~ log(pop_density) + log(green_access_prop) + log(green_access_dist) + 
  log(unemployed_pc + 1) + log(socialrenting_pc + 1) + log(bame_pc) +
  f(area_u, model = "besag", graph = g) +
  f(area_v, model = "iid")

cornwall_model1.5_log <- inla(formula1.5_log,
                         family = "poisson", data = all_vars, E = E,
                         control.compute = (list(dic = TRUE)),
                         control.predictor = list(compute = TRUE)
)
summary(cornwall_model1.5_log)
saveRDS(cornwall_model1.5_log, "cornwall_model1.5_log.rds")

######### 1.5 


########################## Mapping relative risks of model 1.5
head(cornwall_model1.5$summary.fitted.values)

# Add these data points to the map of london, assigning the mean to the estimate of the relative risk
# and 0.025quant and 0.975quant to the lower and upper limits of 95% credible intervals of the risks
mapREPROJECTED$RR <-  cornwall_model1.5_log$summary.fitted.values[, "mean"]
mapREPROJECTED$LL <-  cornwall_model1.5_log$summary.fitted.values[, "0.025quant"]
mapREPROJECTED$UL <-  cornwall_model1.5_log$summary.fitted.values[, "0.975quant"]

############### PLOTTING a Interactive map of the RR

# specify the palette
pal <- colorNumeric(palette = "YlOrRd", domain = mapREPROJECTED$RR)
# specify the labels
labels <- sprintf("<strong> %s </strong> <br/> Observed: %s <br/> Expected: %s <br/>
                  Population density: %s <br/> SMR: %s <br/> RR: %s (%s, %s)",
                  mapREPROJECTED$LSOA11NM, mapREPROJECTED$Y, round(mapREPROJECTED$E, 2),
                  mapREPROJECTED$pop_density, round(mapREPROJECTED$SMR, 2), round(mapREPROJECTED$RR, 2), 
                  round(mapREPROJECTED$LL, 2), round(mapREPROJECTED$UL, 2) ) %>%
  lapply(htmltools::HTML)
# apply final touches and now plot
leaflet(mapREPROJECTED) %>% addTiles() %>%
  addPolygons(color = "grey", weight = 1, fillColor = ~pal(RR), fillOpacity = 0.5,
              highlightOptions = highlightOptions(weight = 4), label = labels,
              labelOptions = labelOptions(style = list("font-weight" = "normal",
                                                       padding = "3px 8px"),
                                          textsize = "15px",
                                          direction = "auto")) %>%
  addLegend(pal = pal, values = ~RR, opacity = 0.5, title = "RR",
            position = "bottomright")



# Computing the range of the two measures 
range(mapREPROJECTED$SMR) # (0.165 to 3.245)
range(mapREPROJECTED$RR)  # (0.810 to 1.744)
# You see that the range of the SMRs is much wider about 1 compared to the range
# of the RR.

####### extracting RR mean, and 90/10 quantile ratio
mean(mapREPROJECTED$RR)

# most at risk / least at risk
ninety1 <- quantile(mapREPROJECTED$RR, .90)
ten1 <- quantile(mapREPROJECTED$RR, .10)
ninety1/ten1


########## plotting the posterior distribution curves of the covariates
### extract the marginal values from the results
marginal_popden <- inla.smarginal(cornwall_model1.5_log$marginals.fixed$`log(pop_density)`)

#create a dataframe in order to plot
marginal_popden <- data.frame(marginal_popden)

# now plot
popden_density <- ggplot(marginal_popden, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[1]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()


# next covariate
### extract the marginal values from the results
marginal_green_prop <- inla.smarginal(cornwall_model1.5_log$marginals.fixed$`log(green_access_prop)`)
#create a dataframe in order to plot
marginal_green_prop <- data.frame(marginal_green_prop)
# now plot
greenprop_density <- ggplot(marginal_green_prop, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[2]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()


# next covariate
### extract the marginal values from the results
marginal_green_dist <- inla.smarginal(cornwall_model1.5_log$marginals.fixed$`log(green_access_dist)`)
#create a dataframe in order to plot
marginal_green_dist <- data.frame(marginal_green_dist)
# now plot
greendist_density <- ggplot(marginal_green_dist, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[3]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()


# next covariate
### extract the marginal values from the results
marginal_unemployed <- inla.smarginal(cornwall_model1.5_log$marginals.fixed$`log(unemployed_pc + 1)`)
#create a dataframe in order to plot
marginal_unemployed <- data.frame(marginal_unemployed)
# now plot
unemployed_density <- ggplot(marginal_unemployed, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[4]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()


# next covariate
### extract the marginal values from the results
marginal_socialrent <- inla.smarginal(cornwall_model1.5_log$marginals.fixed$`log(socialrenting_pc + 1)`)
#create a dataframe in order to plot
marginal_socialrent <- data.frame(marginal_socialrent)
# now plot
socialrent_density <- ggplot(marginal_socialrent, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[5]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()


# next covariate
### extract the marginal values from the results
marginal_bame <- inla.smarginal(cornwall_model1.5_log$marginals.fixed$`log(bame_pc)`)
#create a dataframe in order to plot
marginal_bame <- data.frame(marginal_bame)
# now plot
bame_density <- ggplot(marginal_bame, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[6]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()



###### arrange the ggplot density plots on one page

ggarrange(popden_density, greenprop_density, greendist_density,
          unemployed_density, socialrent_density, bame_density)





















######################################################################################################

# 1st only with the green access and popden covariates
#formula1 <- Y ~ pop_density + green_access_prop + green_access_dist + 
#  f(area_u, model = "besag", graph = g) +
#  f(area_v, model = "iid")

#cornwall_model1 <- inla(formula1,
#                        family = "poisson", data = all_vars, E = E,
#                        control.compute = (list(dic = TRUE)),
#                        control.predictor = list(compute = TRUE)
#)
#summary(cornwall_model1)
#saveRDS(cornwall_model1, "cornwall_model1.rds")


######### 1.5
# MODEL 1.5 with the green access and popden covariates AND sociodemographic variables. I.e., without
# the health access variables
#formula1.5 <- Y ~ pop_density + green_access_prop + green_access_dist + 
#  unemployed_pc + socialrenting_pc + bame_pc +
#  f(area_u, model = "besag", graph = g) +
#  f(area_v, model = "iid")

#cornwall_model1.5 <- inla(formula1.5,
#                          family = "poisson", data = all_vars, E = E,
#                          control.compute = (list(dic = TRUE)),
#                          control.predictor = list(compute = TRUE)
#)
#summary(cornwall_model1.5)
#saveRDS(cornwall_model1.5, "cornwall_model1.5.rds")



########################## Mapping relative risks of model 1.5
#head(cornwall_model1.5$summary.fitted.values)

# Add these data points to the map of london, assigning the mean to the estimate of the relative risk
# and 0.025quant and 0.975quant to the lower and upper limits of 95% credible intervals of the risks
#mapREPROJECTED$RR <-  cornwall_model1.5$summary.fitted.values[, "mean"]
#mapREPROJECTED$LL <-  cornwall_model1.5$summary.fitted.values[, "0.025quant"]
#mapREPROJECTED$UL <-  cornwall_model1.5$summary.fitted.values[, "0.975quant"]

############### PLOTTING a Interactive map of the RR

# specify the palette
#pal <- colorNumeric(palette = "YlOrRd", domain = mapREPROJECTED$RR)
# specify the labels
#labels <- sprintf("<strong> %s </strong> <br/> Observed: %s <br/> Expected: %s <br/>
#                  Population density: %s <br/> SMR: %s <br/> RR: %s (%s, %s)",
#                  mapREPROJECTED$LSOA11NM, mapREPROJECTED$Y, round(mapREPROJECTED$E, 2),
#                  mapREPROJECTED$pop_density, round(mapREPROJECTED$SMR, 2), round(mapREPROJECTED$RR, 2), 
#                  round(mapREPROJECTED$LL, 2), round(mapREPROJECTED$UL, 2) ) %>%
#  lapply(htmltools::HTML)
# apply final touches and now plot
#leaflet(mapREPROJECTED) %>% addTiles() %>%
#  addPolygons(color = "grey", weight = 1, fillColor = ~pal(RR), fillOpacity = 0.5,
#              highlightOptions = highlightOptions(weight = 4), label = labels,
#              labelOptions = labelOptions(style = list("font-weight" = "normal",
#                                                       padding = "3px 8px"),
#                                          textsize = "15px",
#                                          direction = "auto")) %>%
#  addLegend(pal = pal, values = ~RR, opacity = 0.5, title = "RR",
#            position = "bottomright")


# Computing the range of the two measures 
#range(mapREPROJECTED$SMR) # (0.17 to 3.25)
#range(mapREPROJECTED$RR)  #  (0.79 to 1.93)
# You see that the range of the SMRs is much wider about 1 compared to the range
# of the RR.
