# read in necessary packages
library(tidyverse)
library(INLA)
library(spdep)
library(SpatialEpi)
library(ggplot2)
library(plyr)
library(dplyr)
library(readr)
library(sf)
library(rgdal)
library(tmap)
library(RSQLite)
library(tmaptools)
library(leaflet)
library(htmltools)
library(broom)
library(plotly) 
library(geojsonio) 
library(mapview) 
library(crosstalk)
library(viridis)
library(reshape2)
library(shinyjs)
library(janitor)
library(car)
library(corrplot)
library(shades)
library(ggpubr)

# read in the postcode -> OA -> LSOA -> MSOA -> LA lookup table. filter for only london lsoas
ldn <- read_csv(("N:/Term 3/ucfnefa/PCD_OA_LSOA_MSOA_LAD_NOV20_UK_LU/PCD_OA_LSOA_MSOA_LAD_NOV20_UK_LU.csv"),
                col_names = TRUE,
                locale = locale(encoding = "Latin1")) %>%
  dplyr::filter(str_detect(ladcd, "^E09"))
head(ldn)

# keep the code and name columns only
ldn <- ldn[c("lsoa11cd", "lsoa11nm")]
# remove the duplicate lsoa rows, given that there is a row for each postcode
ldn <- ldn[!duplicated(ldn[,c("lsoa11cd", "lsoa11nm")]),]


# Reading in the map of emgland with lsoa boundaries
england_lsoas <- st_read("N:/Term 3/ucfnefa/Lower_Layer_Super_Output_Areas__December_2011__Boundaries_Full_Extent__BFE__EW_V3-shp/Lower_Layer_Super_Output_Areas__December_2011__Boundaries_Full_Extent__BFE__EW_V3.shp")
head(england_lsoas)

# filter to just london 
ldn_lsoas <- inner_join(england_lsoas, ldn, by = c("LSOA11CD" = "lsoa11cd"))
ldn_lsoas <- ldn_lsoas[c("LSOA11CD", "LSOA11NM")]
head(ldn_lsoas)
#rm(england_lsoas)

# plot the outline
plot(ldn_lsoas)

# plotting just the outline of the shape
ldn_lsoas %>%
  st_geometry() %>%
  plot()


#################### read in the covariate from london data store - taken from the census
# ethnic propotions, and mean and median household income lsoa data
# I'll need to read in the pop dnsity data separately because the london data store doesn't provide the 2011 pop den value
# It's an issue because I have the 2011 pop density for cornwall, so they need to match
covariates1 <- read_csv("N:/Term 3/ucfnefa/lsoa_LDS_subset.csv")

# drop the 2013 population density column column
drop <-  c("PPH_2013")
covariates1 <- covariates1[,!(names(covariates1) %in% drop)]

# rename
names(covariates1) <- c("codes", "names", "white_pc", "mixed_pc", "asian_pc", "black_pc", 
                        "other_pc", "bame_pc", "mean_income", "median_income", "socialrenting_pc", "unemployed_pc")
head(covariates1)

# read in the 2011 persons per hectare data
popden <- read_csv("N:/Term 3/ucfnefa/england_popdensity.csv")
names(popden) <- c("names", "code", "pop_density")
popden <- popden[c("code", "pop_density")]

# merge
covariates1 <- inner_join(covariates1, popden, by = c("codes" = "code"))
head(covariates1)

#################### read in the CDRC Access to Health Assets and Hazards dataset # raw scores
covariates2 <- read_csv("N:/Term 3/ucfnefa/allvariableslsoawdeciles.csv")
head(covariates2)
# filter for the lsoa code,  gp, a&e, pharmacy, green (passive) and green (active) accessbitlity columns
covariates2 <- covariates2[c("lsoa11", "gpp_dist", "ed_dist", "pharm_dist", "green_pas", "green_act")]
head(covariates2)
names(covariates2) <- c("lsoa", "gp_access", "ae_access", "pharm_access", "green_access_prop", "green_access_dist")


#################### read in the composite INDEX values CDRC Access to Health Assets and Hazards dataset 
covariates3 <- read_csv("N:/Term 3/ucfnefa/ahahv2domainsindex.csv")
head(covariates3)
# filter for the lsoa code, health domain deciles and blue/green space domain deciles columns
covariates3 <- covariates3[c("lsoa11", "h_exp", "g_exp", "h_dec", "g_dec")]
head(covariates3)
names(covariates3) <- c("lsoa","health_access_valexp", "greenblue_access_valexp", "health_access_deciles", "greenblue_access_deciles")



# merge the dataframes together
ldn_covariates <- inner_join(covariates1, covariates2, by = c("codes" = "lsoa"))
head(ldn_covariates)
# add the remaing columns via another merge
ldn_covariates <- inner_join(ldn_covariates, covariates3, by = c("codes" = "lsoa"))
head(ldn_covariates)

# Checking for na values
apply(ldn_covariates, 2, function(x) any(is.na(x)))

#ldn_covariates <- covariates
# filter for london covariates alone by merging with the london map
#ldn_covariates <- inner_join(ldn_lsoas, covariates, by = c("LSOA11CD" = "codes"))
#head(ldn_covariates)

# drop the repeated lsoa name column
#drop <-  c("LSOA11NM")
#ldn_covariates <- ldn_covariates[,!(names(ldn_covariates) %in% drop)]

# the geometry is 'sticky', so to get rid of the geometry column I will set geometry to NULL
#ldn_covariates <- st_set_geometry(ldn_covariates, NULL)
#head(ldn_covariates)

# clean the names
#ldn_covariates <- ldn_covariates %>%
#  clean_names()
#head(ldn_covariates)



########### Checking the distribution of the covariates
###### I'll also use Tukey's ladder of transformations to see if and how the covariates need to be transformed
## Persons per hectare - population density
ggplot(ldn_covariates, aes(x = pop_density)) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 10) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)

symbox(~pop_density, 
       ldn_covariates,
       na.rm=T,
       powers = seq(-2,2,by=.5))


## Total BAME ethnic percentage
ggplot(ldn_covariates, aes(x = bame_pc )) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 0.5) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)

symbox(~bame_pc, 
       ldn_covariates,
       na.rm=T,
       powers = seq(-2,2,by=.5))

 
## Green space (passive) access 
ggplot(ldn_covariates, aes(x = green_access_prop)) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 0.1) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)    

symbox(~green_access_prop, 
       ldn_covariates,
       na.rm=T,
       powers = seq(-2,2,by=.5))

## Green space (active) access 
ggplot(ldn_covariates, aes(x = green_access_dist)) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 0.1) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)

symbox(~green_access_dist, 
       ldn_covariates,
       na.rm=T,
       powers = seq(-2,2,by=.5))


## Socially rented accomodation %
ggplot(ldn_covariates, aes(x = socialrenting_pc)) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 1) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)

symbox(~socialrenting_pc, 
       ldn_covariates,
       na.rm=T,
       powers = seq(-2,2,by=.5))


## Unemployment rate
ggplot(ldn_covariates, aes(x = unemployed_pc)) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 1) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)

symbox(~unemployed_pc, 
       ldn_covariates,
       na.rm=T,
       powers = seq(-2,2,by=.5))




################################# read in neuro-psychiatric hospitalisation data: observed counts, 
#expected counted and standardised mortality ratio have already been computed 
d2011 <- read_csv("N:/Term 3/emmanuel/data/dataLSOA1y/UK83C_gbd1a0_2E_2011.csv")

# take only relevant columns
d2011 <- d2011[, c("X1", "eObs", "eExp", "smr")]
# rename columns
names(d2011) <- c("lsoa", "Y", "E", "SMR")
head(d2011)

# merge with the ldn_covariates data frame
all_vars <- inner_join(ldn_covariates, d2011, by = c("codes" = "lsoa"))
head(all_vars)

# reorder the columns
all_vars <- all_vars[c("codes", "names", "Y", "E", "SMR", "pop_density", 
                       "green_access_prop", "green_access_dist",
                       "unemployed_pc", "socialrenting_pc",
                       "median_income",  "bame_pc")]

# reorder the rows
all_vars <- all_vars[order(all_vars$names),]

# We need to create index vectors for the lsoas that will be used to specify the random effects of the model
all_vars$area_u <- 1:nrow(all_vars)
head(all_vars)

# we need to make a second index vector for the lsoas because there are two different random effects
all_vars$area_v <- all_vars$area_u
head(all_vars)

############ computing means and ranges of covariates
mean(all_vars$pop_density) # 96.0
range(all_vars$pop_density)

mean(all_vars$green_access_prop) # 0.74
range(all_vars$green_access_prop)

mean(all_vars$green_access_dist) # 0.41
range(all_vars$green_access_dist)

mean(all_vars$unemployed_pc) # 7.4
range(all_vars$unemployed_pc)

mean(all_vars$socialrenting_pc) # 23.5
range(all_vars$socialrenting_pc)

mean(all_vars$bame_pc) # 39.3
range(all_vars$bame_pc)



############################################
# what shape is the observed data? want to see which model is most suitable
## Green and Blue space access 
ggplot(all_vars, aes(x = Y )) +
  geom_histogram(aes(y = ..density..),
                 binwidth = 1) +
  geom_density(colour = "red", 
               size = 1,
               adjust =1)








### before modelling, I will plot an interactive map of the 2011 SMRs across London
##############################################################

# join london data with the map of london 
map <- inner_join(ldn_lsoas, all_vars, by = c("LSOA11CD" = "codes"))
# drop the repeated lso names column
drop <-  c("names")
map <- map[,!(names(map) %in% drop)]



# For the interactive map, because I'm using leaflet, I Need '+proj=longlat +datum=WGS84' 

# Checking projection of my map of London
print(map) #Returns Projected CRS: OSGB 1936 / British National Grid
# which has the epsg code of 4326

# Reproject
mapREPROJECTED <- map %>%
  st_transform(., 4326)
print(mapREPROJECTED)

# Now we'll improve that map by hghlighting things about the lsoa as the mose hovers over them
pal <- colorNumeric(palette = "YlOrRd", domain = mapREPROJECTED$SMR)
labels <- sprintf("<strong> %s </strong> <br/> Observed: %s <br/> Expected: %s <br/>
                  Population density: %s <br/> SMR: %s",
                  mapREPROJECTED$LSOA11NM, mapREPROJECTED$Y, round(mapREPROJECTED$E, 2),
                  mapREPROJECTED$pop_density, round(mapREPROJECTED$SMR, 2)) %>%
  lapply(htmltools::HTML)

twenty_11 <- leaflet(mapREPROJECTED) %>% addTiles() %>%
  addPolygons(color = "grey", weight = 1, fillColor = ~pal(SMR), fillOpacity = 0.5,
              highlightOptions = highlightOptions(weight = 4), label = labels,
              labelOptions = labelOptions(style = list("font-weight" = "normal",
                                                       padding = "3px 8px"),
                                          textsize = "15px",
                                          direction = "auto")) %>%
  addLegend(pal = pal, values = ~SMR, opacity = 0.5, title = "SMR",
            position = "bottomright")

twenty_11


####### extracting SMR mean, range, and 90/10 quantile ratio
mean(all_vars$SMR)
range(all_vars$SMR)

# most at risk / least at risk
ninety <- quantile(all_vars$SMR, .90)
ten <- quantile(all_vars$SMR, .10)
ninety/ten


############### Computing Correlation Matrix

cMartixVars <- all_vars[c("pop_density", 
                          "green_access_prop", "green_access_dist", 
                          "unemployed_pc", "socialrenting_pc","bame_pc")]

cMatrix <- cor(cMartixVars)
head(round(cMatrix, 2))

corrplot(cMatrix, method = "number")



################################### MODELLING using the Bernardinelli model (Bernadinelli et al., 1995)

# First we need to create a neighbourhood matrix to define the spatial random effect
#by using the poly2nb() and the nb2INLA() functions of the spdep package (Bivand, 2019).
nb <- poly2nb(ldn_lsoas)
summary(nb)
#class(nb)

# create the neighbours matrix
#nb2INLA("london.adj", nb)
g <- inla.read.graph(filename = "london.adj")
#summary(g)
#head(g)







# Now write the formula of the Bernardinelli model:

# Model 0000000000000000000000 zero - just the unstructuctured spatial residual Vi
# I will then compute MORAN'S I to check for spatial autocorrelation in the RR
formula0 <- Y ~ log(pop_density) + log(green_access_prop) + log(green_access_dist) +
  f(area_v, model = "iid")

ldn_model0 <- inla(formula0,
                   family= "poisson", data = all_vars, E=E,
                   control.compute = (list(dic = TRUE)),
                   control.predictor = list(compute = TRUE)
)
summary(ldn_model0)
saveRDS(ldn_model0, "ldn_model0.rds")


# NOW for Moran's I
# We'll keep with the Queen's neighbourhood structure as it is the default (used here) 
# for the INLA models. We'll also use the Binary spatial weights

# Creating the binary spatial weights matric from the queens neighbourhood structure
lsoa_weights_m <- nb %>%
  nb2mat(., style = "B")
sum(lsoa_weights_m)

# changing the spatial weights matrix into a list as Moran's I requires it this way
lsoa_weights_m <- nb %>%
  nb2listw(., style = "B")

# Extract the residuals
head(ldn_model0$summary.random$area_v)
residuals_vi <- ldn_model0$summary.random$area_v[,"mean"]
head(residuals_vi)


# Going to use the Monte-Carlo simulation of Moran's I, rather than the basic analytical approach of 
# The analytical apprach is fast, but the MC simulative approach is a safer approach as it takes an 
# extra argument n, the number of simulations
I_Llsoa_binary <- moran.mc(x = residuals_vi, listw = lsoa_weights_m, nsim = 1000)   
I_Llsoa_binary














                                                  # with LOGGED COVARIATES #
############################################################################################################################################               

# 1st only with the green access and popden covariates
formula1_log <- Y ~ log(pop_density) + log(green_access_prop) + log(green_access_dist) + 
  f(area_u, model = "besag", graph = g) +
  f(area_v, model = "iid")

ldn_model1_log <- inla(formula1_log,
                    family = "poisson", data = all_vars, E = E,
                    control.compute = (list(dic = TRUE)),
                    control.predictor = list(compute = TRUE)
)
summary(ldn_model1_log)
saveRDS(ldn_model1_log, "ldn_model1_log.rds")



######### 1.5
# this model initially gave an error as 4 logged values became Inf's, suggesting that there were zeros or negative values
# After inspection it turns out there are neither negative values nor zeros in any of the columns,
# however, the social renting column has a few values that are close to zero (e.g. 0.4) 
# so I will apply  log(social renting pc + 1) and see if it works

# MODEL 1.5 with the green access and popden covariates AND sociodemographic variables. I.e., without
# the health access variables
formula1.5_log <- Y ~ log(pop_density) + log(green_access_prop) + log(green_access_dist) + 
  log(unemployed_pc + 1) + log(socialrenting_pc + 1) + log(bame_pc) +
  f(area_u, model = "besag", graph = g) +
  f(area_v, model = "iid")

ldn_model1.5_log <- inla(formula1.5_log,
                     family = "poisson", data = all_vars, E = E,
                     control.compute = (list(dic = TRUE)),
                     control.predictor = list(compute = TRUE)
)
summary(ldn_model1.5_log)
saveRDS(ldn_model1.5_log, "ldn_model1.5_log.rds")

######### 1.5 



######################################################################
####### Mapping relative risks of model 1.5
head(ldn_model1.5_log$summary.fitted.values)

# Add these data points to the map of london, assigning the mean to the estimate of the relative risk
# and 0.025quant and 0.975quant to the lower and upper limits of 95% credible intervals of the risks
mapREPROJECTED$RR <-  ldn_model1.5_log$summary.fitted.values[, "mean"]
mapREPROJECTED$LL <-  ldn_model1.5_log$summary.fitted.values[, "0.025quant"]
mapREPROJECTED$UL <-  ldn_model1.5_log$summary.fitted.values[, "0.975quant"]

############### PLOTTING a Interactive map of the RR

# specify the palette
pal <- colorNumeric(palette = "YlOrRd", domain = mapREPROJECTED$RR)
# specify the labels
labels <- sprintf("<strong> %s </strong> <br/> Observed: %s <br/> Expected: %s <br/>
                  Population density: %s <br/> SMR: %s <br/> RR: %s (%s, %s)",
                  mapREPROJECTED$LSOA11NM, mapREPROJECTED$Y, round(mapREPROJECTED$E, 2),
                  mapREPROJECTED$pop_density, round(mapREPROJECTED$SMR, 2), round(mapREPROJECTED$RR, 2), 
                  round(mapREPROJECTED$LL, 2), round(mapREPROJECTED$UL, 2) ) %>%
  lapply(htmltools::HTML)
# apply final touches and now plot
leaflet(mapREPROJECTED) %>% addTiles() %>%
  addPolygons(color = "grey", weight = 1, fillColor = ~pal(RR), fillOpacity = 0.5,
              highlightOptions = highlightOptions(weight = 4), label = labels,
              labelOptions = labelOptions(style = list("font-weight" = "normal",
                                                       padding = "3px 8px"),
                                          textsize = "15px",
                                          direction = "auto")) %>%
  addLegend(pal = pal, values = ~RR, opacity = 0.5, title = "RR",
            position = "bottomright")


# Computing the range of the two measures 
range(mapREPROJECTED$SMR) # 
range(mapREPROJECTED$RR)  #  
# You see that the range of the SMRs is much wider about 1 compared to the range
# of the RR.
# We can also compare the maps of the SMRs and RRs by using the same scale on the gadient legend

####### extracting RR mean, and 90/10 quantile ratio
mean(mapREPROJECTED$RR)

# most at risk / least at risk
ninety1 <- quantile(mapREPROJECTED$RR, .90)
ten1 <- quantile(mapREPROJECTED$RR, .10)
ninety1/ten1


# specify the palette
pal <- colorNumeric(palette = "YlOrRd", domain = mapREPROJECTED$SMR)

# plot
leaflet(mapREPROJECTED) %>% addTiles() %>%
  addPolygons(color = "grey", weight = 1, fillColor = ~pal(RR), fillOpacity = 0.5,
              highlightOptions = highlightOptions(weight = 4), label = labels,
              labelOptions = labelOptions(style = list("font-weight" = "normal",
                                                       padding = "3px 8px"),
                                          textsize = "15px",
                                          direction = "auto")) %>%
  addLegend(pal = pal, values = ~RR, opacity = 0.5, title = "RR",
            position = "bottomright")




########## plotting the posterior distribution curves of the covariates
### extract the marginal values from the results
marginal_popden <- inla.smarginal(ldn_model1.5_log$marginals.fixed$`log(pop_density)`)

#create a dataframe in order to plot
marginal_popden <- data.frame(marginal_popden)

# now plot
popden_density <- ggplot(marginal_popden, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[1]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()


# next covariate
### extract the marginal values from the results
marginal_green_prop <- inla.smarginal(ldn_model1.5_log$marginals.fixed$`log(green_access_prop)`)
#create a dataframe in order to plot
marginal_green_prop <- data.frame(marginal_green_prop)
# now plot
greenprop_density <- ggplot(marginal_green_prop, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[2]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()


# next covariate
### extract the marginal values from the results
marginal_green_dist <- inla.smarginal(ldn_model1.5_log$marginals.fixed$`log(green_access_dist)`)
#create a dataframe in order to plot
marginal_green_dist <- data.frame(marginal_green_dist)
# now plot
greendist_density <- ggplot(marginal_green_dist, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[3]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()


# next covariate
### extract the marginal values from the results
marginal_unemployed <- inla.smarginal(ldn_model1.5_log$marginals.fixed$`log(unemployed_pc + 1)`)
#create a dataframe in order to plot
marginal_unemployed <- data.frame(marginal_unemployed)
# now plot
unemployed_density <- ggplot(marginal_unemployed, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[4]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()


# next covariate
### extract the marginal values from the results
marginal_socialrent <- inla.smarginal(ldn_model1.5_log$marginals.fixed$`log(socialrenting_pc + 1)`)
#create a dataframe in order to plot
marginal_socialrent <- data.frame(marginal_socialrent)
# now plot
socialrent_density <- ggplot(marginal_socialrent, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[5]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()


# next covariate
### extract the marginal values from the results
marginal_bame <- inla.smarginal(ldn_model1.5_log$marginals.fixed$`log(bame_pc)`)
#create a dataframe in order to plot
marginal_bame <- data.frame(marginal_bame)
# now plot
bame_density <- ggplot(marginal_bame, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[6]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()



###### arrange the ggplot density plots on one page

ggarrange(popden_density, greenprop_density, greendist_density,
          unemployed_density, socialrent_density, bame_density)















############################################################################################################################

# reminding myself of the cornwall results
#cornwall1 <- readRDS("cornwall_model1.rds")              
#summary(cornwall1)

#cornwall1.5 <- readRDS("cornwall_model1.5.rds")              
#summary(cornwall1.5)


# now the logged results
#cornwall1_log <- readRDS("cornwall_model1_log.rds")              
#summary(cornwall1_log)

#corwall1.5_log <- readRDS("cornwall_model1.5_log.rds")
#summary(corwall1.5_log)


################################################################################################################################


# 1st "proper model" with only the green access and popden covariates
#formula1 <- Y ~ pop_density + green_access_prop + green_access_dist + 
#  f(area_u, model = "besag", graph = g) +
#  f(area_v, model = "iid")

#ldn_model1 <- inla(formula1,
#                   family = "poisson", data = all_vars, E = E,
#                   control.compute = (list(dic = TRUE)),
#                   control.predictor = list(compute = TRUE)
#)
#summary(ldn_model1)
#saveRDS(ldn_model1, "ldn_model1.rds")




######### 1.5

# MODEL 1.5 with the green access and popden covariates AND sociodemographic variables. I.e., without
# the health access variables
#formula1.5 <- Y ~ pop_density + green_access_prop + green_access_dist + 
#  unemployed_pc + socialrenting_pc + bame_pc +
#  f(area_u, model = "besag", graph = g) +
#  f(area_v, model = "iid")

#ldn_model1.5 <- inla(formula1.5,
#                     family = "poisson", data = all_vars, E = E,
#                     control.compute = (list(dic = TRUE)),
#                     control.predictor = list(compute = TRUE)
#)
#summary(ldn_model1.5)
#saveRDS(ldn_model1.5, "ldn_model1.5.rds")


######################################################################
####### Mapping relative risks of model 1.5
#head(ldn_model1.5$summary.fitted.values)

# Add these data points to the map of london, assigning the mean to the estimate of the relative risk
# and 0.025quant and 0.975quant to the lower and upper limits of 95% credible intervals of the risks
#mapREPROJECTED$RR <-  ldn_model1.5$summary.fitted.values[, "mean"]
#mapREPROJECTED$LL <-  ldn_model1.5$summary.fitted.values[, "0.025quant"]
#mapREPROJECTED$UL <-  ldn_model1.5$summary.fitted.values[, "0.975quant"]

############### PLOTTING a Interactive map of the RR

# specify the palette
#pal <- colorNumeric(palette = "YlOrRd", domain = mapREPROJECTED$RR)
# specify the labels
#labels <- sprintf("<strong> %s </strong> <br/> Observed: %s <br/> Expected: %s <br/>
#                  Population density: %s <br/> SMR: %s <br/> RR: %s (%s, %s)",
#                    mapREPROJECTED$LSOA11NM, mapREPROJECTED$Y, round(mapREPROJECTED$E, 2),
#                    mapREPROJECTED$pop_density, round(mapREPROJECTED$SMR, 2), round(mapREPROJECTED$RR, 2), 
#                    round(mapREPROJECTED$LL, 2), round(mapREPROJECTED$UL, 2) ) %>%
#  lapply(htmltools::HTML)
# apply final touches and now plot
#leaflet(mapREPROJECTED) %>% addTiles() %>%
#  addPolygons(color = "grey", weight = 1, fillColor = ~pal(RR), fillOpacity = 0.5,
#              highlightOptions = highlightOptions(weight = 4), label = labels,
#              labelOptions = labelOptions(style = list("font-weight" = "normal",
#                                                      padding = "3px 8px"),
#                                          textsize = "15px",
#                                          direction = "auto")) %>%
#  addLegend(pal = pal, values = ~RR, opacity = 0.5, title = "RR",
#            position = "bottomright")


# Computing the range of the two measures 
#range(mapREPROJECTED$SMR) # (0.00 to 3.68)
#range(mapREPROJECTED$RR)  #  (0.74 to 2.54)
# You see that the range of the SMRs is much wider about 1 compared to the range
# of the RR.